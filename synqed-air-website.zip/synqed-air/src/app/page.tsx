import CorridorMap from "@/components/CorridorMap";

const CORRIDORS = [
  {
    route: "Lagos — London",
    detail:
      "The busiest diaspora corridor out of Lagos. Fares compared across every carrier flying it, not just the ones with ad budgets.",
  },
  {
    route: "Lagos — Houston",
    detail:
      "One of the fastest-growing US corridors for Nigerian travelers. Layover options ranked by real total travel time, not just price.",
  },
  {
    route: "Lagos — Toronto",
    detail:
      "Built for the back-and-forth: visiting family, moving for school, or relocating for good. Visa and eTA guidance included.",
  },
];

const PRICE_ROWS = [
  {
    typical: "A fare that looks cheap until checkout",
    ours: "The fare you see is the fare you pay",
  },
  {
    typical: "Baggage, seat, and card fees added one screen at a time",
    ours: "Every fee itemized before you enter payment details",
  },
  {
    typical: "Currency conversion buried in the exchange rate",
    ours: "Naira and card charges shown side by side, no markup hidden in the spread",
  },
  {
    typical: "Refund and change rules you find out about after booking",
    ours: "Change and refund terms shown on the fare, before you choose it",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-ink text-paper">
      {/* Nav */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-7 md:px-10">
        <span className="font-display text-lg font-semibold tracking-tight">
          Synqed Air
        </span>
        <nav className="hidden items-center gap-8 text-sm text-paper-dim md:flex">
          <a href="#pricing" className="transition-colors hover:text-paper">
            Pricing
          </a>
          <a href="#corridors" className="transition-colors hover:text-paper">
            Corridors
          </a>
          <a href="#companion" className="transition-colors hover:text-paper">
            Companion
          </a>
        </nav>
        <a
          href="#waitlist"
          className="rounded-full border border-gold px-4 py-2 text-sm font-medium text-gold transition-colors hover:bg-gold hover:text-ink"
        >
          Get early access
        </a>
      </header>

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 pb-20 pt-10 md:grid-cols-[1.1fr_1fr] md:gap-6 md:px-10 md:pt-16">
        <div className="max-w-xl">
          <h1 className="font-display text-4xl font-semibold leading-[1.08] tracking-tight md:text-6xl">
            Every fee, before you pay for it.
          </h1>
          <p className="mt-6 max-w-md text-lg leading-relaxed text-paper-dim">
            Synqed Air books flights on the routes the diaspora actually
            flies — Lagos to London, Houston, Toronto and beyond — with the
            full price shown up front and an AI advisor that finds the
            itinerary that fits your trip.
          </p>

          <form
            id="waitlist"
            className="mt-9 flex max-w-md flex-col gap-3 sm:flex-row"
          >
            <label htmlFor="email" className="sr-only">
              Email address
            </label>
            <input
              id="email"
              type="email"
              required
              placeholder="you@email.com"
              className="w-full rounded-full border border-line bg-ink-2 px-5 py-3 text-sm text-paper placeholder:text-paper-dim/60 focus:border-gold focus:outline-none focus-visible:ring-2 focus-visible:ring-gold"
            />
            <button
              type="submit"
              className="shrink-0 rounded-full bg-gold px-6 py-3 text-sm font-semibold text-ink transition-colors hover:bg-gold-dim"
            >
              Join the waitlist
            </button>
          </form>
          <p className="mt-3 text-sm text-paper-dim">
            Launching to the first corridors before the end of 2026.
          </p>
        </div>

        <div className="h-72 w-full md:h-96">
          <CorridorMap />
        </div>
      </section>

      {/* Pricing transparency */}
      <section
        id="pricing"
        className="border-t border-line-soft bg-ink-2 px-6 py-20 md:px-10"
      >
        <div className="mx-auto max-w-6xl">
          <div className="max-w-lg">
            <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
              We show you the fare a different way
            </h2>
            <p className="mt-4 leading-relaxed text-paper-dim">
              Most booking sites earn more the more confusing the checkout
              gets. Synqed Air doesn&apos;t work that way — here&apos;s the
              difference.
            </p>
          </div>

          <div className="mt-12 divide-y divide-line-soft border-y border-line-soft">
            {PRICE_ROWS.map((row) => (
              <div
                key={row.typical}
                className="grid gap-4 py-6 md:grid-cols-2 md:gap-10"
              >
                <p className="text-paper-dim/80 line-through decoration-line">
                  {row.typical}
                </p>
                <p className="font-medium text-paper">{row.ours}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Corridors */}
      <section id="corridors" className="px-6 py-20 md:px-10">
        <div className="mx-auto max-w-6xl">
          <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
            Where we&apos;re starting
          </h2>
          <p className="mt-4 max-w-lg leading-relaxed text-paper-dim">
            A small set of corridors, chosen for how often the diaspora
            actually flies them — not the routes that are easiest to sell
            ads against.
          </p>

          <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-line-soft bg-line-soft md:grid-cols-3">
            {CORRIDORS.map((c) => (
              <div key={c.route} className="bg-ink-2 p-7">
                <h3 className="font-display text-xl font-semibold text-gold">
                  {c.route}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-paper-dim">
                  {c.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI advisor + Companion */}
      <section
        id="companion"
        className="border-t border-line-soft bg-ink-2 px-6 py-20 md:px-10"
      >
        <div className="mx-auto grid max-w-6xl gap-12 md:grid-cols-2">
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight md:text-3xl">
              An advisor that reads your trip, not just your search
            </h2>
            <p className="mt-4 leading-relaxed text-paper-dim">
              Tell it what matters — cheapest fare, shortest layover, a
              specific arrival day for a wedding or a visa appointment — and
              it narrows the search itself, with the reasoning shown, not
              hidden behind a black box.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight md:text-3xl">
              Companion: the part after you book
            </h2>
            <p className="mt-4 leading-relaxed text-paper-dim">
              Check-in reminders timed to your flight, visa and eTA guidance
              for your destination, and a saved-passenger profile so the
              next trip takes two minutes, not twenty.
            </p>
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="px-6 py-24 text-center md:px-10">
        <h2 className="font-display mx-auto max-w-2xl text-3xl font-semibold tracking-tight md:text-4xl">
          Be the first to book when we open the first corridor
        </h2>
        <a
          href="#waitlist"
          className="mt-8 inline-block rounded-full bg-gold px-7 py-3 text-sm font-semibold text-ink transition-colors hover:bg-gold-dim"
        >
          Join the waitlist
        </a>
      </section>

      <footer className="border-t border-line-soft px-6 py-10 md:px-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-paper-dim md:flex-row">
          <span>© {new Date().getFullYear()} Synqed Air</span>
          <span>Built for the diaspora corridor.</span>
        </div>
      </footer>
    </div>
  );
}
