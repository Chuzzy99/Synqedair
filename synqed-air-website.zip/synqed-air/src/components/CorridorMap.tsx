const CITIES = [
  { name: "Lagos", x: 240, y: 330, hub: true },
  { name: "London", x: 300, y: 90 },
  { name: "Houston", x: 60, y: 150 },
  { name: "Toronto", x: 470, y: 60 },
];

const HUB = CITIES[0];
const SPOKES = CITIES.slice(1);

function arcPath(x1: number, y1: number, x2: number, y2: number) {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2 - 55;
  return `M ${x1} ${y1} Q ${mx} ${my} ${x2} ${y2}`;
}

export default function CorridorMap() {
  return (
    <svg
      viewBox="0 0 560 400"
      className="h-full w-full"
      role="img"
      aria-label="Stylized diagram of Synqed Air's diaspora flight corridors, connecting Lagos to London, Houston, and Toronto"
    >
      <title>Synqed Air launch corridors, radiating from Lagos</title>

      {SPOKES.map((city) => (
        <path
          key={city.name}
          d={arcPath(HUB.x, HUB.y, city.x, city.y)}
          fill="none"
          stroke="var(--line)"
          strokeWidth="1.5"
          strokeDasharray="1 7"
          strokeLinecap="round"
        />
      ))}

      {SPOKES.map((city) => (
        <g key={`${city.name}-dot`}>
          <circle cx={city.x} cy={city.y} r={4} fill="var(--paper-dim)" />
          <text
            x={city.x}
            y={city.y - 14}
            textAnchor="middle"
            fill="var(--paper-dim)"
            fontFamily="var(--font-body)"
            fontSize="13"
          >
            {city.name}
          </text>
        </g>
      ))}

      <circle cx={HUB.x} cy={HUB.y} r={7} fill="var(--gold)" />
      <circle
        cx={HUB.x}
        cy={HUB.y}
        r={13}
        fill="none"
        stroke="var(--gold)"
        strokeWidth="1"
        opacity="0.5"
      />
      <text
        x={HUB.x}
        y={HUB.y + 26}
        textAnchor="middle"
        fill="var(--paper)"
        fontFamily="var(--font-display)"
        fontWeight={600}
        fontSize="15"
      >
        Lagos
      </text>
    </svg>
  );
}
