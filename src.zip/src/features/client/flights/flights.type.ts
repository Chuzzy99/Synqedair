import type { CABIN_CLASSES } from './flights.validation';

export type { SearchFlightsPayload } from './flights.validation';

export type CabinClass = (typeof CABIN_CLASSES)[number];

/* ---------- Response from POST /flights/search ---------- */

export interface FlightPlace {
  code: string | null;
  name: string;
  city: string;
}

export interface FlightSegmentPlace extends FlightPlace {
  terminal: string | null;
}

export interface FlightCarrier {
  name: string;
  iataCode: string | null;
  logo: string | null;
}

export interface FlightBaggage {
  type: 'checked' | 'carry_on';
  quantity: number;
}

export interface FlightSegment {
  id: string;
  origin: FlightSegmentPlace;
  destination: FlightSegmentPlace;
  departingAt: string; // ISO date-time, local to the airport
  arrivingAt: string;
  duration: string | null; // ISO 8601, e.g. "PT7H5M"
  carrier: FlightCarrier;
  operatingCarrier: string;
  flightNumber: string;
  aircraft: string | null;
  cabinClass: string | null;
  baggages: FlightBaggage[];
}

// One direction of the trip: 1 slice for one-way, 2 for round trip
export interface FlightSlice {
  id: string;
  origin: FlightPlace;
  destination: FlightPlace;
  duration: string | null; // ISO 8601
  stops: number;
  fareBrandName: string | null;
  segments: FlightSegment[];
}

export interface FlightChangeCondition {
  allowed: boolean;
  penalty_amount: string | null;
  penalty_currency: string | null;
}

export interface FlightOffer {
  id: string;

  // Prices already include the Synqed Air service fee
  baseAmount: string;
  taxAmount: string | null;
  totalAmount: string;
  totalCurrency: string;

  serviceFee: {
    name: string;
    amount: string;
  };

  expiresAt: string;
  emissionsKg: string | null;
  identityDocumentsRequired: boolean;

  payment: {
    requiresInstantPayment: boolean;
    paymentRequiredBy: string | null;
    priceGuaranteeExpiresAt: string | null;
  };

  conditions: {
    changeBeforeDeparture: FlightChangeCondition | null;
    refundBeforeDeparture: FlightChangeCondition | null;
  };

  airline: FlightCarrier & { iataCode: string | null };

  passengers: { id: string; type: string | null }[];

  slices: FlightSlice[];
}

export interface SearchFlightsResponseData {
  offerRequestId: string;
  count: number;
  offers: FlightOffer[];
}

/* ---------- Client-side sorting (applied after results arrive) ---------- */

export type FlightSortKey = 'best_value' | 'cheapest' | 'fastest';