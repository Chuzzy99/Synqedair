'use client';

import { useQuery } from '@tanstack/react-query';

import * as flightsApi from '@/features/client/flights/flights.api';
import { getApiErrorMessage } from '@/lib/apiError';
import type { SearchFlightsPayload } from '@/features/client/flights/flights.type';

export const flightKeys = {
  search: (params: SearchFlightsPayload | null) => ['flights', 'search', params] as const,
};

/**
 * Searches flights through our backend.
 *
 * Pass `null` to stay idle (e.g. the user opened /search from a popular-route
 * card and hasn't filled in the form yet). Passing real params runs the search.
 */
export const useSearchFlights = (params: SearchFlightsPayload | null) => {
  const query = useQuery({
    queryKey: flightKeys.search(params),
    queryFn: async () => {
      const response = await flightsApi.searchFlights(params as SearchFlightsPayload);
      return response.data;
    },
    enabled: params !== null,

    // Offers expire, so don't keep results around for long
    staleTime: 5 * 60 * 1000,

    // A failed search is usually a bad route/date, so retrying just makes the user wait
    retry: false,
    refetchOnWindowFocus: false,
  });

  return {
    offers: query.data?.offers ?? [],
    offerRequestId: query.data?.offerRequestId ?? null,
    count: query.data?.count ?? 0,

    // True only while a search is actually running (false when idle)
    isSearching: query.isLoading,
    isError: query.isError,
    errorMessage: query.isError
      ? getApiErrorMessage(query.error, 'Flight search failed. Please try again.')
      : null,

    // True once a search has returned, even with zero results
    hasSearched: query.isSuccess,

    refetch: query.refetch,
  };
};