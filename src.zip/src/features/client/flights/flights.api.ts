import { client } from '@/client-setup/client';
import type { ApiResponse } from '@/types/api';
import type {
  SearchFlightsPayload,
  SearchFlightsResponseData,
} from '@/features/client/flights/flights.type';

export const searchFlights = async (payload: SearchFlightsPayload) => {
  const { data } = await client.post<ApiResponse<SearchFlightsResponseData>>(
    '/flights/search',
    payload
  );
  return data;
};