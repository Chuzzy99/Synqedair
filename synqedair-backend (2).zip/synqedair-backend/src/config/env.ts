import "dotenv/config";

function required(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(
      `Missing required environment variable: ${key}. Copy .env.example to .env and fill it in.`
    );
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT ?? 4000),
  nodeEnv: process.env.NODE_ENV ?? "development",

  claudeApiKey: required("CLAUDE_API_KEY"),
  claudeModel: process.env.CLAUDE_MODEL ?? "claude-haiku-4-5-20251001",

  duffelApiKey: required("DUFFEL_API_KEY"),
  duffelApiBase: process.env.DUFFEL_API_BASE ?? "https://api.duffel.com",

  paystackSecretKey: required("PAYSTACK_SECRET_KEY"),
  paystackApiBase: process.env.PAYSTACK_API_BASE ?? "https://api.paystack.co",

  databaseUrl: process.env.DATABASE_URL ?? "",
};
