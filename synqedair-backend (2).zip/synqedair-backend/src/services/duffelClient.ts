import { env } from "../config/env";
import type { FlightOffer, FlightSearchRequest, FeeBreakdown, RankingLabel } from "../types";

// NOTE: Duffel's exact request/response shape and header requirements can
// change — verify field names and the Duffel-Version header against
// https://duffel.com/docs/api before wiring this up for real. This client
// covers the core flow (create an offer request, read back offers) so the
// rest of the app has a stable internal shape to build against regardless.

const SYNQEDAIR_SERVICE_FEE_NGN = 3500; // flat, disclosed booking fee — see pricing doc

interface DuffelOfferRequestBody {
  data: {
    slices: Array<{ origin: string; destination: string; departure_date: string }>;
    passengers: Array<{ type: "adult" }>;
    cabin_class?: "economy" | "premium_economy" | "business" | "first";
  };
}

async function duffelFetch(path: string, options: RequestInit = {}): Promise<any> {
  const res = await fetch(`${env.duffelApiBase}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${env.duffelApiKey}`,
      "Content-Type": "application/json",
      "Duffel-Version": "v2", // confirm current version against Duffel docs
      Accept: "application/json",
      ...options.headers,
    },
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Duffel API error ${res.status}: ${body}`);
  }
  return res.json();
}

function rankOffers(offers: FlightOffer[]): FlightOffer[] {
  if (offers.length === 0) return offers;

  const cheapest = [...offers].sort((a, b) => a.fees.total - b.fees.total)[0];
  const fastest = [...offers].sort((a, b) => a.durationMinutes - b.durationMinutes)[0];

  // "Best value" — a simple weighted score of price vs duration.
  // Tune the weights once you have real conversion data from the beta.
  const maxPrice = Math.max(...offers.map((o) => o.fees.total));
  const maxDuration = Math.max(...offers.map((o) => o.durationMinutes));
  const scored = offers.map((o) => ({
    offer: o,
    score: 0.6 * (o.fees.total / maxPrice) + 0.4 * (o.durationMinutes / maxDuration),
  }));
  const bestValue = scored.sort((a, b) => a.score - b.score)[0].offer;

  return offers.map((o) => {
    const ranking: RankingLabel[] = [];
    if (o.id === bestValue.id) ranking.push("best_value");
    if (o.id === fastest.id) ranking.push("fastest");
    if (o.id === cheapest.id) ranking.push("cheapest");
    return { ...o, ranking };
  });
}

export async function searchFlights(request: FlightSearchRequest): Promise<FlightOffer[]> {
  const body: DuffelOfferRequestBody = {
    data: {
      slices: [
        {
          origin: request.origin,
          destination: request.destination,
          departure_date: request.departDate,
        },
      ],
      passengers: Array.from({ length: request.passengers || 1 }, () => ({ type: "adult" })),
      cabin_class: "economy",
    },
  };

  const offerRequest = await duffelFetch("/air/offer_requests?return_offers=true", {
    method: "POST",
    body: JSON.stringify(body),
  });

  const rawOffers: any[] = offerRequest.data?.offers ?? [];

  const offers: FlightOffer[] = rawOffers.map((offer) => {
    const slice = offer.slices[0];
    const firstSegment = slice.segments[0];
    const lastSegment = slice.segments[slice.segments.length - 1];
    const stops = slice.segments.length - 1;

    const fare = Number(offer.base_amount ?? offer.total_amount) - Number(offer.tax_amount ?? 0);
    const taxes = Number(offer.tax_amount ?? 0);
    const bags = 0; // Duffel returns baggage as separate services — add once bags are wired up
    const serviceFee = SYNQEDAIR_SERVICE_FEE_NGN;

    const fees: FeeBreakdown = {
      fare,
      taxes,
      bags,
      serviceFee,
      total: fare + taxes + bags + serviceFee,
      currency: offer.total_currency ?? "NGN",
    };

    return {
      id: offer.id,
      airline: offer.owner?.name ?? "Unknown",
      flightNumber: `${firstSegment.marketing_carrier?.iata_code ?? ""}${firstSegment.marketing_carrier_flight_number ?? ""}`,
      origin: firstSegment.origin.iata_code,
      destination: lastSegment.destination.iata_code,
      departAt: firstSegment.departing_at,
      arriveAt: lastSegment.arriving_at,
      stops,
      stopAirport: stops > 0 ? slice.segments[0].destination.iata_code : null,
      durationMinutes: Math.round(
        (new Date(lastSegment.arriving_at).getTime() - new Date(firstSegment.departing_at).getTime()) / 60000
      ),
      ranking: [],
      fees,
    };
  });

  return rankOffers(offers);
}
