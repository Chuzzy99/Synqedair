import Anthropic from "@anthropic-ai/sdk";
import { env } from "../config/env";
import type { AdvisorParseResponse } from "../types";

const anthropic = new Anthropic({ apiKey: env.claudeApiKey });

// Tool definition that forces Claude to return structured search params
// instead of free text. This is the core of the "AI Travel Advisor" screen.
const PARSE_TOOL = {
  name: "extract_flight_search",
  description:
    "Extract structured flight search parameters from a traveler's natural-language request.",
  input_schema: {
    type: "object" as const,
    properties: {
      origin: { type: "string", description: "IATA airport/city code, or null if not mentioned" },
      destination: { type: "string", description: "IATA airport/city code, or null if not mentioned" },
      departDate: { type: "string", description: "ISO date (YYYY-MM-DD), or null if not mentioned" },
      returnDate: { type: "string", description: "ISO date (YYYY-MM-DD), or null for one-way" },
      budgetAmount: { type: "number", description: "Numeric budget if mentioned, else null" },
      budgetCurrency: { type: "string", description: "3-letter currency code, e.g. NGN, USD" },
      passengers: { type: "number", description: "Number of travelers, default 1" },
      preferences: {
        type: "array",
        items: { type: "string" },
        description: "e.g. no_layovers, visa_free_only, cheapest, fastest",
      },
      confidence: { type: "string", enum: ["high", "medium", "low"] },
      clarifyingQuestion: {
        type: "string",
        description: "If confidence is low, a short question to ask the traveler. Else null.",
      },
    },
    required: ["passengers", "preferences", "confidence"],
  },
};

export async function parseTravelQuery(query: string): Promise<AdvisorParseResponse> {
  const message = await anthropic.messages.create({
    model: env.claudeModel, // Haiku-class model: fast + cheap for intent parsing
    max_tokens: 512,
    system:
      "You turn a traveler's plain-language flight request into structured search parameters. " +
      "Today's context: assume Nigeria-based traveler unless stated otherwise. " +
      "If the request is ambiguous, set confidence to low and ask ONE short clarifying question.",
    messages: [{ role: "user", content: query }],
    tools: [PARSE_TOOL],
    tool_choice: { type: "tool", name: "extract_flight_search" },
  });

  const toolUse = message.content.find((block) => block.type === "tool_use");
  if (!toolUse || toolUse.type !== "tool_use") {
    throw new Error("Claude did not return structured search parameters");
  }

  const parsed = toolUse.input as Record<string, unknown>;

  return {
    origin: (parsed.origin as string) ?? null,
    destination: (parsed.destination as string) ?? null,
    departDate: (parsed.departDate as string) ?? null,
    returnDate: (parsed.returnDate as string) ?? null,
    budgetAmount: (parsed.budgetAmount as number) ?? null,
    budgetCurrency: (parsed.budgetCurrency as string) ?? null,
    passengers: (parsed.passengers as number) ?? 1,
    preferences: (parsed.preferences as string[]) ?? [],
    confidence: (parsed.confidence as "high" | "medium" | "low") ?? "low",
    clarifyingQuestion: (parsed.clarifyingQuestion as string) ?? null,
  };
}
