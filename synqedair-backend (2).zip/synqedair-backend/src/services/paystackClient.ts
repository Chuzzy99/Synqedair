import { env } from "../config/env";

interface InitializeTransactionParams {
  email: string;
  amountNaira: number; // Paystack expects kobo (amount * 100)
  reference: string;
  currency?: "NGN" | "USD" | "GHS" | "ZAR" | "KES";
}

interface InitializeTransactionResult {
  authorizationUrl: string;
  accessCode: string;
  reference: string;
}

interface PaystackResponse {
  status: boolean;
  message: string;
  data: any;
}

async function paystackFetch(path: string, options: RequestInit = {}): Promise<PaystackResponse> {
  const res = await fetch(`${env.paystackApiBase}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${env.paystackSecretKey}`,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  const json = (await res.json()) as PaystackResponse;
  if (!res.ok || json.status === false) {
    throw new Error(`Paystack API error: ${json.message ?? res.statusText}`);
  }
  return json;
}

// Local cards: 1.5% + ₦100, capped ₦2,000. International cards: 3.9% + ₦100,
// uncapped. Paystack deducts its fee from the settlement automatically —
// this helper is for showing the traveler an accurate total, not for
// collecting the fee separately.
export async function initializeTransaction(
  params: InitializeTransactionParams
): Promise<InitializeTransactionResult> {
  const json = await paystackFetch("/transaction/initialize", {
    method: "POST",
    body: JSON.stringify({
      email: params.email,
      amount: Math.round(params.amountNaira * 100), // kobo
      reference: params.reference,
      currency: params.currency ?? "NGN",
    }),
  });

  return {
    authorizationUrl: json.data.authorization_url,
    accessCode: json.data.access_code,
    reference: json.data.reference,
  };
}

export async function verifyTransaction(reference: string) {
  const json = await paystackFetch(`/transaction/verify/${encodeURIComponent(reference)}`, {
    method: "GET",
  });
  return json.data;
}
