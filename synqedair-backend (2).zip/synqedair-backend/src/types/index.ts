// These shapes are the contract between this backend and both mobile apps
// (Flutter primary build, React Native reference build). Keep this file and
// the Flutter models / RN types in sync — see docs/API_CONTRACT.md.

export interface AdvisorParseRequest {
  query: string;
}

export interface AdvisorParseResponse {
  origin: string | null; // IATA code, e.g. "LOS"
  destination: string | null; // IATA code, e.g. "NBO"
  departDate: string | null; // ISO date, e.g. "2026-09-15"
  returnDate: string | null;
  budgetAmount: number | null;
  budgetCurrency: string | null; // e.g. "NGN"
  passengers: number;
  preferences: string[]; // e.g. ["no_layovers", "visa_free_only"]
  confidence: "high" | "medium" | "low";
  clarifyingQuestion: string | null; // set when confidence is low
}

export type RankingLabel = "best_value" | "fastest" | "cheapest";

export interface FeeBreakdown {
  fare: number;
  taxes: number;
  bags: number;
  serviceFee: number;
  total: number;
  currency: string;
}

export interface FlightOffer {
  id: string;
  airline: string;
  flightNumber: string;
  origin: string;
  destination: string;
  departAt: string; // ISO datetime
  arriveAt: string; // ISO datetime
  stops: number;
  stopAirport: string | null;
  durationMinutes: number;
  ranking: RankingLabel[];
  fees: FeeBreakdown;
}

export interface FlightSearchRequest {
  origin: string;
  destination: string;
  departDate: string;
  returnDate?: string;
  passengers: number;
}

export interface FlightSearchResponse {
  offers: FlightOffer[];
}

export interface CreateBookingRequest {
  offerId: string;
  passengerName: string;
  passengerEmail: string;
  passengerPhone: string;
}

export interface CreateBookingResponse {
  bookingId: string;
  status: "pending_payment" | "confirmed";
  paymentAuthorizationUrl: string;
}
