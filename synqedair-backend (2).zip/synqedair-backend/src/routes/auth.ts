import { Router } from "express";
import { z } from "zod";

export const authRouter = Router();

// Phone + OTP auth, per the build plan (more trusted than email/password
// for a first-time-online-booking audience). Needs an SMS provider
// (Termii and Africa's Talking both cover Nigeria/Kenya well — pick one
// in week 1 alongside the other vendor sign-ups) wired in before this does
// anything real. Stubbed here so the mobile app has a stable contract to
// build the login screen against from day one.

const requestOtpSchema = z.object({ phone: z.string().min(10) });
const verifyOtpSchema = z.object({ phone: z.string().min(10), code: z.string().length(6) });

// POST /api/auth/request-otp
// Body: { phone: string }  →  { sent: true }
authRouter.post("/request-otp", async (req, res) => {
  const parsed = requestOtpSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid phone number" });

  // TODO: generate a 6-digit code, store it (Redis, 5 min TTL), send via SMS provider
  console.log(`[stub] would send OTP to ${parsed.data.phone}`);
  res.json({ sent: true });
});

// POST /api/auth/verify-otp
// Body: { phone: string, code: string }  →  { token: string, userId: string }
authRouter.post("/verify-otp", async (req, res) => {
  const parsed = verifyOtpSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid request" });

  // TODO: check code against stored value, create/find user, issue a real JWT
  res.json({ token: "stub-token-replace-with-real-jwt", userId: "stub-user-id" });
});
