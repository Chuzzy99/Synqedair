import { Router } from "express";
import { z } from "zod";
import { parseTravelQuery } from "../services/claudeClient";

export const advisorRouter = Router();

const parseRequestSchema = z.object({
  query: z.string().min(1).max(500),
});

// POST /api/advisor/parse
// Body: { query: string }
// Returns: AdvisorParseResponse (see src/types/index.ts)
advisorRouter.post("/parse", async (req, res) => {
  const parsed = parseRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
  }

  try {
    const result = await parseTravelQuery(parsed.data.query);
    res.json(result);
  } catch (err) {
    console.error("Advisor parse failed:", err);
    res.status(502).json({ error: "AI advisor is temporarily unavailable" });
  }
});
