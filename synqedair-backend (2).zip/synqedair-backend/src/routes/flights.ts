import { Router } from "express";
import { z } from "zod";
import { searchFlights } from "../services/duffelClient";

export const flightsRouter = Router();

const searchQuerySchema = z.object({
  origin: z.string().length(3),
  destination: z.string().length(3),
  departDate: z.string(), // ISO date
  returnDate: z.string().optional(),
  passengers: z.coerce.number().min(1).max(9).default(1),
});

// GET /api/flights/search?origin=LOS&destination=NBO&departDate=2026-09-15&passengers=1
// Returns: { offers: FlightOffer[] }
flightsRouter.get("/search", async (req, res) => {
  const parsed = searchQuerySchema.safeParse(req.query);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
  }

  try {
    const offers = await searchFlights(parsed.data);
    res.json({ offers });
  } catch (err) {
    console.error("Flight search failed:", err);
    res.status(502).json({ error: "Flight search is temporarily unavailable" });
  }
});
