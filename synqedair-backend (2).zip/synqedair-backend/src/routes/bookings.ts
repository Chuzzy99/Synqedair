import { Router } from "express";
import { randomUUID } from "crypto";
import { z } from "zod";
import { initializeTransaction } from "../services/paystackClient";

export const bookingsRouter = Router();

const createBookingSchema = z.object({
  offerId: z.string().min(1),
  passengerName: z.string().min(1),
  passengerEmail: z.string().email(),
  passengerPhone: z.string().min(7),
  amountNaira: z.number().positive(), // total from the offer's fee breakdown
});

// POST /api/bookings
// Body: CreateBookingRequest + amountNaira (total from the offer shown to the traveler)
// Returns: CreateBookingResponse
//
// This does NOT call Duffel's order creation yet — that should only happen
// after Paystack confirms payment (via webhook), not before. Wire the
// webhook handler up in week 9 per the build plan before going further here.
bookingsRouter.post("/", async (req, res) => {
  const parsed = createBookingSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid request", details: parsed.error.flatten() });
  }

  const { passengerEmail, amountNaira } = parsed.data;
  const bookingId = randomUUID();

  try {
    // TODO: persist a "pending_payment" booking row keyed by bookingId
    // before initializing payment, so the webhook has something to update.
    const transaction = await initializeTransaction({
      email: passengerEmail,
      amountNaira,
      reference: bookingId,
    });

    res.status(201).json({
      bookingId,
      status: "pending_payment",
      paymentAuthorizationUrl: transaction.authorizationUrl,
    });
  } catch (err) {
    console.error("Booking creation failed:", err);
    res.status(502).json({ error: "Could not start payment for this booking" });
  }
});
