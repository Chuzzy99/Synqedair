import express from "express";
import cors from "cors";
import { env } from "./config/env";
import { advisorRouter } from "./routes/advisor";
import { flightsRouter } from "./routes/flights";
import { bookingsRouter } from "./routes/bookings";
import { authRouter } from "./routes/auth";

const app = express();

app.use(cors()); // lock this down to the app's actual origin(s) before launch
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true, env: env.nodeEnv }));

app.use("/api/advisor", advisorRouter);
app.use("/api/flights", flightsRouter);
app.use("/api/bookings", bookingsRouter);
app.use("/api/auth", authRouter);

app.listen(env.port, () => {
  console.log(`SynqedAir backend listening on port ${env.port}`);
});
