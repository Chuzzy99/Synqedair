# SynqedAir Backend

Node.js + TypeScript API: AI advisor, flight search, bookings, payments.

## Quick start

```bash
npm install
cp .env.example .env   # fill in real API keys
npm run dev             # starts on http://localhost:4000
```

Confirm it's running: `curl http://localhost:4000/health` → `{"ok":true}`

## Structure

```
src/
  index.ts           Express app entry point
  config/env.ts       Typed environment config, throws on missing keys
  routes/
    advisor.ts         POST /api/advisor/parse
    flights.ts          GET /api/flights/search
    bookings.ts         POST /api/bookings
    auth.ts             POST /api/auth/request-otp, /verify-otp (stubbed)
  services/
    claudeClient.ts     Wraps the Claude API for NL -> structured search
    duffelClient.ts     Wraps Duffel flight search + ranking logic
    paystackClient.ts   Wraps Paystack payment initialization
  types/index.ts       Shared request/response shapes -- the API contract
```

## What's real vs. stubbed

- **Advisor, flights, bookings**: real implementations against the Claude,
  Duffel, and Paystack APIs. They need real API keys in `.env` to actually
  return data — verify field names against current Duffel docs before
  wiring up production traffic, their schema can shift.
- **Auth**: stubbed. Returns a fake token so the mobile app has a stable
  contract to build the login screen against immediately. Wire up a real
  SMS provider (Termii or Africa's Talking both cover NG/KE well) and JWT
  issuance in week 3 per the build plan.
- **Booking confirmation after payment**: not built yet. Add a Paystack
  webhook handler that verifies the transaction and only *then* creates the
  Duffel order — never create the airline order before payment is confirmed.

## Environment variables

See `.env.example`. Get keys from:
- Claude: console.anthropic.com
- Duffel: duffel.com (start on their test/sandbox key)
- Paystack: dashboard.paystack.com (start on the test secret key)

## Type checking

```bash
npm run typecheck
```
