import { Router } from 'express'
import { z } from 'zod'
import { validate } from '../../middleware/validateMiddleware.js'
import { searchFlightsSchema } from './flights.validation.js'
import { searchFlightsController } from './flights.contoller.js'

const router = Router()

router.post('/search', validate({ body: searchFlightsSchema }), searchFlightsController)

export default router